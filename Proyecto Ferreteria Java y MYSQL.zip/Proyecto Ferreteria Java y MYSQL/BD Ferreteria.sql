﻿CREATE DATABASE empresa;
USE empresa;
CREATE TABLE ciudad(
ciudadID INT NOT NULL AUTO_INCREMENT,
ciudadNombre VARCHAR (25)NOT NULL,
CONSTRAINT pkCiudad PRIMARY KEY (ciudadID),
CONSTRAINT uqCiudad UNIQUE (ciudadNombre)
);

CREATE TABLE comuna(
comunaID INT NOT NULL AUTO_INCREMENT,
comunaNombre VARCHAR(25)NOT NULL,
CONSTRAINT pkComuna PRIMARY KEY (comunaID),
CONSTRAINT uqComuna UNIQUE (comunaNombre)
);

CREATE TABLE FormaPago(
FormaPago_ID SMALLINT NOT NULL AUTO_INCREMENT,
FormaPago_Nombre VARCHAR(45) NOT NULL,
CONSTRAINT pkFormaPago PRIMARY KEY (FormaPago_ID),
CONSTRAINT uqFormaPago UNIQUE (FormaPago_Nombre));

CREATE TABLE producto(
productoID INT NOT NULL AUTO_INCREMENT,
productoNombre VARCHAR(25)NOT NULL,
productoPrecio INT NOT NULL,
CONSTRAINT pkProducto PRIMARY KEY(productoID),
CONSTRAINT uqProducto UNIQUE (productoNombre),
CONSTRAINT chkProducto CHECK (productoPrecio>0)
);

CREATE TABLE roles(
rolID INT NOT NULL AUTO_INCREMENT,
rolNombre VARCHAR (35)NOT NULL,
CONSTRAINT pkRoles PRIMARY KEY (rolID),
CONSTRAINT chkRoles CHECK (rolNombre='Administrador' OR rolNombre='Digitador')
);

CREATE TABLE usuario(
usuarioID INT NOT NULL AUTO_INCREMENT,
nombreUsuario VARCHAR(25)NOT NULL,
contraseña VARCHAR(15)NOT NULL,
rolID INT NOT NULL,
CONSTRAINT pkUsuario PRIMARY KEY (usuarioID),
CONSTRAINT fkUsuario FOREIGN KEY (rolID) REFERENCES roles(rolID),
CONSTRAINT uqUsuario UNIQUE (nombreUsuario)
);

CREATE TABLE cliente(
clienteRut VARCHAR(15) NOT NULL,
clienteNombre VARCHAR(35) NOT NULL,
clienteDireccion VARCHAR(50)NOT NULL,
clienteGiro VARCHAR(50)NOT NULL,
clienteContacto INT NOT NULL,
ciudadID INT NOT NULL,
comunaID INT NOT NULL,
CONSTRAINT pkCliente PRIMARY KEY(clienteRut),
CONSTRAINT fk1Cliente FOREIGN KEY (ciudadID)REFERENCES ciudad(ciudadID),
CONSTRAINT fk2Cliente FOREIGN KEY (comunaID)REFERENCES comuna(comunaID)
);

CREATE TABLE Factura(
Factura_ID INTEGER AUTO_INCREMENT NOT NULL, 
Factura_Fecha DATE NOT NULL,
clienteRut CHAR(11) NOT NULL,
Factura_FechaVencimiento DATE NOT NULL,
FormaPago_ID SMALLINT NOT NULL,
Factura_Referencias VARCHAR(250),
Factura_Neto INTEGER NOT NULL,
Factura_Iva INTEGER NOT NULL,
Factura_Total INTEGER NOT NULL,
Factura_DolarCambio DOUBLE NOT NULL,
CONSTRAINT pkFactura PRIMARY KEY (Factura_ID),
CONSTRAINT fk1Factura FOREIGN KEY (clienteRut) REFERENCES Cliente(clienteRut),
CONSTRAINT fk2Factura FOREIGN KEY (FormaPago_ID) REFERENCES FormaPago(FormaPago_ID)
);

CREATE TABLE Detalle(
Factura_ID INTEGER NOT NULL, 
productoID INT NOT NULL ,
Detalle_Cantidad SMALLINT NOT NULL,
CONSTRAINT pkDetalle PRIMARY KEY (Factura_ID, productoID),
CONSTRAINT fk1Detalle FOREIGN KEY (Factura_ID) REFERENCES Factura(Factura_ID),
CONSTRAINT fk2Detalle FOREIGN KEY (productoID) REFERENCES Producto(productoID),
CONSTRAINT chkDetalle CHECK (Detalle_Cantidad>0)
);
####################################################################################

INSERT INTO ciudad VALUES(1,'Puerto Montt');
INSERT INTO comuna VALUES(3,'Llanquihue');
INSERT INTO formaPago VALUES(7,'Banco estado');
INSERT INTO producto VALUES(9,'Cierra Electrica',60.000);
INSERT INTO roles VALUES(1,'Administrador');
INSERT INTO roles VALUES(2,'Digitador');
INSERT INTO usuario VALUES(15,'Norman','contraseña1234',1);
INSERT INTO cliente VALUES('19674464-9','Gerald','Tambor Jose Aguila','Negocio Familiar',97899564,1,3);
INSERT INTO factura VALUES(20,('2020-05-10'), '19674464-9', ('2020-08-10'), 7, 'Prodctos de calidad', 60.000, 19, 71.000, 100000);
INSERT INTO detalle VALUES(20, 9, 10);


