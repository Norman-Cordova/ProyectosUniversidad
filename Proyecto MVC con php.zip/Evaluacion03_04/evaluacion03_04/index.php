<?php

$controlador = "usuarios";
$accion = "inicioLogin";

if(isset($_REQUEST['controlador']) && isset($_REQUEST['accion']) ){

  if(($_REQUEST['controlador'] != '')&&($_REQUEST['accion'] != '')){
    $controlador = $_REQUEST['controlador'];
    $accion = $_REQUEST['accion'];
  }

}
if($accion == "inicioLogin"){
  require_once('./vistas/templateLogin.php');
}else{
  require_once('./vistas/template.php');
}




?>
