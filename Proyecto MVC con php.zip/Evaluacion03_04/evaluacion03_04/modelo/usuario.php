<?php
class Usuario{

   public $id;
   public $nombre;
   public $rol ;
   public $contraseña ;

   public function __construct($id,$nombre,$rol,$contraseña){
       $this->id=$id;
       $this->nombre=$nombre;
       $this->rol=$rol;
       $this->contraseña=$contraseña;
   }

   public static function consultar(){
       $listaDeUsuarios = [];
       $conexionBD = BD::crearInstancia();
       $sql = $conexionBD->query("SELECT u.id,u.nombre,r.rol,u.contraseña FROM usuarios u INNER JOIN roles r ON u.rolid=r.id;");

       foreach($sql->fetchAll() as $usuario){
           $listaDeUsuarios[] = new Usuario($usuario['id'],$usuario['nombre'],$usuario['rol'],$usuario['contraseña']);

       }
       return $listaDeUsuarios;
   }

   public static function crear($nombre,$idRol,$contraseña){

       $conexionBD = BD::crearInstancia();

       $sql = $conexionBD->prepare("INSERT INTO usuarios(nombre,rolid,contraseña) VALUES(?,?,?);");

       $sql->execute(array($nombre,$idRol,$contraseña));

   }

   public static function borrar($id){

       $conexionBD = BD::crearInstancia();

       $sql = $conexionBD->prepare("DELETE FROM usuarios WHERE id=?");
       $sql->execute(array($id));
   }

   public static function editar($nombre,$contraseña,$rolid,$id){
       $conexionBD = BD::crearInstancia();
       $sql = $conexionBD->prepare("UPDATE  usuarios SET nombre=?, contraseña=?,rolid=? WHERE id=? ");
       $sql->execute(array($nombre,$contraseña,$rolid,$id));
   }

   public static function validar($nombre,$contraseña,$usuarios){
     $listaDeUsuarios = $usuarios;
     $respuesta = "NoEncontrado";
     foreach($listaDeUsuarios as $usuario){
       if($usuario->nombre == $nombre && $usuario->contraseña == $contraseña){
         $respuesta = array($usuario->nombre);
       }
     }
     return $respuesta;
   }

}

?>
