
  $(() => {
      $("#formularioCrearEmpleados").validate({
        rules: {
          nombre:{
            required: true ,
            maxlength: 20
          },
          correo: {
            required: true ,
            email:true
          }
        },
        messages:{
          nombre: {
            maxlength:'Solo es un nombre',
            required: 'Ingrese un nombre de empleado'
          },
          correo: {
            required:'Debe Ingresar un email',
            email: 'debe ingresar un email valido'
          }
        },
        submitHandler: (form) => {
          form.submit()
        }
      });
      $("#formularioCrearUsuario").validate({
        rules: {
          nombre:{
            required: true ,
            maxlength: 20
          },
          contraseña: {
            required: true ,
            minlength: 8
          }
        },
        messages:{
          nombre: {
            required: 'Ingrese un nombre se usuario',
            maxlength: 'Debe ser un nombre de usuario corto'
          },
          contraseña: {
            required: 'Debe Ingresar una contraseña',
            minlength: 'La contraseña debe ser de 8 caracteres'
          }
        },
        submitHandler: (form) => {
          form.submit()
        }
      });



  })
