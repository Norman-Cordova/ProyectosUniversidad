<div class="card">
    <!--bs5-card-head-foot-->
    <div class="card-header">
        Agregar Empleado
    </div>
    <div class="card-body">
       <form action="" method="post">
           <!--bs5-form-input-->
           <div class="mb-3">
             <label for="id" class="form-label">ID:</label>
             <input readonly type="text"
               class="form-control" value="<?php echo $id; ?>" name="id" id="id" aria-describedby="helpId" placeholder="ID Empleado">

           </div>

           <!--bs5-form-input-->
        <div class="mb-3">
          <label for="nombre" class="form-label">Nombre:</label>
          <input required type="text"
            class="form-control" value="<?php echo $nombre; ?>" name="nombre" id="nombre" aria-describedby="helpId" placeholder="Nombre del Empleado">

        </div>

        <!--bs5-form-email-->
        <div class="mb-3">
          <label for="correo" class="form-label">Correo:</label>
          <input type="email" value="<?php echo $correo; ?>" class="form-control" name="correo" id="correo" aria-describedby="emailHelpId" placeholder="Correo del Empleado">
        </div>

        <!--bs5-button-input-->
        <input required name="" id="" class="btn btn-success" type="submit" value="Editar Empleado">
        <a href="?controlador=empleados&accion=inicio" class="btn btn-primary">Cancelar</a>

       </form>
    </div>

</div>
