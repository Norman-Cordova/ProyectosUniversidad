
<div class="card">
    <div class="card-header">
        Editar Usuario
    </div>
    <div class="card-body">
       <form  method="post">

         <div class="mb-3">
           <label for="ide" class="form-label">ID:</label>
           <input disabled required type="text"
             class="form-control" name="ide" id="ide" value="<?php echo $_REQUEST["id"]; ?>" aria-describedby="helpId" placeholder="Nombre del Usuario">

         </div>
         <input type="hidden" name="controlador" value="usuarios">
         <input type="hidden" name="id" value="<?php echo $_REQUEST["id"]; ?>">

      <div class="mb-3">
        <label for="nombre" class="form-label">Nombre:</label>
        <input required type="text"
          class="form-control" name="nombre" id="nombre" value="<?php echo $_REQUEST["nombre"]; ?>" aria-describedby="helpId" placeholder="Nombre del Usuario">

      </div>

      <div class="mb-3">
        <label for="rol" class="form-label">Rol:</label>
        <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
          <input value="1" type="radio" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off" checked>
          <label class="btn btn-outline-primary" for="btnradio1">Digitador</label>

          <input value="2" type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off">
          <label class="btn btn-outline-primary" for="btnradio2">Empaquetador</label>

          <input value="3" type="radio" class="btn-check" name="btnradio" id="btnradio3" autocomplete="off">
          <label class="btn btn-outline-primary" for="btnradio3">Administrador</label>

          <input value="4" type="radio" class="btn-check" name="btnradio" id="btnradio4" autocomplete="off">
          <label class="btn btn-outline-primary" for="btnradio4">Vendedor</label>
        </div>

      </div>

      <div class="mb-3">
        <label for="contraseña" class="form-label">Contraseña:</label>
        <input required type="text" class="form-control" name="contraseña" id="contraseña" value="<?php echo $_REQUEST["contraseña"]; ?>" aria-describedby="emailHelpId" placeholder="Contraseña del Usuario">
      </div>


      <input name="" id="" class="btn btn-success" type="submit" value="Editar Usuario">

      <a href="?controlador=usuarios&accion=inicio" class="btn btn-primary">Cancelar</a>

       </form>
    </div>

</div>
