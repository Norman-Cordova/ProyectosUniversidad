<?php
    class ControladorPaginas{


        public function inicio(){
            include_once('vistas/paginas/inicio.php');

        }
    }
?>
