<?php
  include_once("modelo/empleado.php");
  include_once("modelo/conexion.php");

  BD::crearInstancia();

  class ControladorEmpleados{
    public function inicio(){

      $empleados = Empleado::consultar();

      include_once("vistas/empleados/inicio.php");
    }

    public function editar(){
      if($_GET){
        $id = $_GET["id"];
        $nombre = $_GET["nombre"];
        $correo = $_GET["correo"];
      include_once("vistas/empleados/editar.php");
      }
      if($_POST){
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $correo = $_POST["correo"];
        Empleado::editar($id,$nombre,$correo);
        header("Location:./?controlador=empleados&accion=inicio");
      }
    }

    public function crear(){
      if($_POST){
        $nombre = $_POST["nombre"];
        $correo = $_POST["correo"];
        Empleado::crear($nombre,$correo);
        header("Location:./?controlador=empleados&accion=inicio");
      }
      include_once("vistas/empleados/crear.php");

    }

    public function borrar(){
      if($_REQUEST){
        $id = $_REQUEST["id"];
        Empleado::borrar($id);
        header("Location:./?controlador=empleados&accion=inicio");
      }
    }

  }
 ?>
