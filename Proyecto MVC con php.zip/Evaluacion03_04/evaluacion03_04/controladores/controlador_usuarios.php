<?php
  include_once("modelo/usuario.php");
  include_once("modelo/conexion.php");

  BD::crearInstancia();

  class ControladorUsuarios{

    public function inicioLogin(){
        include_once('vistas/paginas/inicioLogin.php');
    }

    public function inicio(){
      $usuarios = Usuario::consultar();

      include_once("vistas/usuarios/inicio.php");
    }

    public function editar(){

      if($_GET){
        $id = $_GET["id"];
        $nombre = $_GET["nombre"];
        $contraseña = $_GET["contraseña"];
        echo "En editar de Get";
      include_once("vistas/usuarios/editar.php");
      }
      if($_POST){
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $btnradio = $_POST["btnradio"];
        $contraseña = $_POST["contraseña"];
        Usuario::editar($nombre,$contraseña,$btnradio,$id);
        header("Location:./?controlador=usuarios&accion=inicio");
      }
    }

    public function crear(){
      if($_POST){
        $nombre = $_POST["nombre"];
        $btnRadio = $_POST["btnradio"];
        $contraseña = $_POST["contraseña"];
        Usuario::crear($nombre,$btnRadio,$contraseña);
        header("Location:./?controlador=usuarios&accion=inicio");
      }
      include_once("vistas/usuarios/crear.php");

    }

    public function borrar(){
      if($_REQUEST){
        $id = $_REQUEST["id"];
        Usuario::borrar($id);
        header("Location:./?controlador=usuarios&accion=inicio");
      }
    }
    public function validarUsuario(){
      if(isset($_REQUEST['nombre']) && isset($_REQUEST['contraseña'])){
        $nombre = $_GET["nombre"];
        $contraseña = $_GET["contraseña"];
        $usuarios = Usuario::consultar();
        $respuesta = Usuario::validar($nombre,$contraseña,$usuarios);
        print_r($respuesta);

        if ($respuesta == "NoEncontrado"){
          header("Location:./");
        }else{
          header("Location:./?controlador=paginas&accion=inicio&n=".$nombre);
        }
      }
    }

  }
 ?>
