package Controlador;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Estudiante;

/**
 * Servlet implementation class BuscarDatos
 */
@WebServlet("/BuscarDatos")
public class BuscarDatos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuscarDatos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd = request.getRequestDispatcher("/AgregarModificar.jsp");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Prueba4");
		EntityManager em = emf.createEntityManager();
		int id = Integer.parseInt(request.getParameter("id"));
		Estudiante e = em.find(Estudiante.class, id);
		
			
		try {
			request.setAttribute("id", String.valueOf(id));
			request.setAttribute("nombre", e.getNombres());
			request.setAttribute("apellidos", e.getApellidos());
			DateFormat fecha = new SimpleDateFormat("yyyy-MM-dd");
			String convertido = fecha.format(e.getFechaingreso());
			request.setAttribute("fecha", convertido);
		}catch(Exception ex) {
			
		}
			
		rd.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
