package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the asignatura database table.
 * 
 */
@Entity
@NamedQuery(name="Asignatura.findAll", query="SELECT a FROM Asignatura a")
public class Asignatura implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String id;

	private int horas;

	private String nombre;

	//bi-directional many-to-one association to Enrolamiento
	@OneToMany(mappedBy="asignatura")
	private List<Enrolamiento> enrolamientos;

	public Asignatura() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getHoras() {
		return this.horas;
	}

	public void setHoras(int horas) {
		this.horas = horas;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Enrolamiento> getEnrolamientos() {
		return this.enrolamientos;
	}

	public void setEnrolamientos(List<Enrolamiento> enrolamientos) {
		this.enrolamientos = enrolamientos;
	}

	public Enrolamiento addEnrolamiento(Enrolamiento enrolamiento) {
		getEnrolamientos().add(enrolamiento);
		enrolamiento.setAsignatura(this);

		return enrolamiento;
	}

	public Enrolamiento removeEnrolamiento(Enrolamiento enrolamiento) {
		getEnrolamientos().remove(enrolamiento);
		enrolamiento.setAsignatura(null);

		return enrolamiento;
	}

}