package model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the estudiante database table.
 * 
 */
@Entity
@NamedQuery(name="Estudiante.findAll", query="SELECT e FROM Estudiante e ORDER BY e.fechaingreso DESC")
public class Estudiante implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	private String apellidos;

	@Temporal(TemporalType.DATE)
	private Date fechaingreso;

	private String nombres;

	//bi-directional many-to-one association to Enrolamiento
	@OneToMany(mappedBy="estudiante")
	private List<Enrolamiento> enrolamientos;

	public Estudiante() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getApellidos() {
		return this.apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Date getFechaingreso() {
		return this.fechaingreso;
	}

	public void setFechaingreso(Date fechaingreso) {
		this.fechaingreso = fechaingreso;
	}

	public String getNombres() {
		return this.nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public List<Enrolamiento> getEnrolamientos() {
		return this.enrolamientos;
	}

	public void setEnrolamientos(List<Enrolamiento> enrolamientos) {
		this.enrolamientos = enrolamientos;
	}

	public Enrolamiento addEnrolamiento(Enrolamiento enrolamiento) {
		getEnrolamientos().add(enrolamiento);
		enrolamiento.setEstudiante(this);

		return enrolamiento;
	}

	public Enrolamiento removeEnrolamiento(Enrolamiento enrolamiento) {
		getEnrolamientos().remove(enrolamiento);
		enrolamiento.setEstudiante(null);

		return enrolamiento;
	}

}