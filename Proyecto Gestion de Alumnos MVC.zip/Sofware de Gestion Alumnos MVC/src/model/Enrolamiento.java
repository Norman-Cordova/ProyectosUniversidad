package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the enrolamiento database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name="Enrolamiento.findAll", query="SELECT e FROM Enrolamiento e"),
	@NamedQuery(name="borrar", query="DELETE FROM Enrolamiento e WHERE e.id = :id")
})

public class Enrolamiento implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int id;

	//bi-directional many-to-one association to Asignatura
	@ManyToOne
	@JoinColumn(name="idasignatura")
	private Asignatura asignatura;

	//bi-directional many-to-one association to Estudiante
	@ManyToOne
	@JoinColumn(name="idestudiante")
	private Estudiante estudiante;

	public Enrolamiento() {
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Asignatura getAsignatura() {
		return this.asignatura;
	}

	public void setAsignatura(Asignatura asignatura) {
		this.asignatura = asignatura;
	}

	public Estudiante getEstudiante() {
		return this.estudiante;
	}

	public void setEstudiante(Estudiante estudiante) {
		this.estudiante = estudiante;
	}

}