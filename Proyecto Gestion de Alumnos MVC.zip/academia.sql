create database academia;

use academia;

create table estudiante (
  id            int primary key,
  apellidos     varchar(50),
  nombres       varchar(50),
  fechaingreso  date
);

create table asignatura (
  id      varchar(6) primary key,
  nombre  varchar(50),
  horas   int
);

create table enrolamiento (
  id            int primary key,
  idestudiante  int not null,
  idasignatura  varchar(6) not null,
  constraint fk_estud foreign key (idestudiante) references estudiante (id),
  constraint fk_asign foreign key (idasignatura) references asignatura (id)
);

insert into estudiante values (101,'Zurita Arancibia','Alberto','2018-03-02');
insert into estudiante values (102,'Vasquez Briones','Beatriz','2018-03-04');
insert into estudiante values (103,'Torres Carmona','Carlos','2018-03-05');
insert into estudiante values (104,'Saavedra Donoso','Denisse','2018-03-08');

insert into asignatura values ('TIDC04','Programacion de componentes web',90);
insert into asignatura values ('TIGS05','Taller de base de datos',72);
insert into asignatura values ('TIHI07','Taller de diseño de aplicaciones',72);

insert into enrolamiento values (1,101,'TIDC04');
insert into enrolamiento values (2,101,'TIGS05');
insert into enrolamiento values (3,102,'TIHI07');
insert into enrolamiento values (4,103,'TIDC04');
insert into enrolamiento values (5,103,'TIGS05');
insert into enrolamiento values (6,103,'TIHI07');
insert into enrolamiento values (7,104,'TIDC04');

